# Agrupamento 676 Links — V1.1

Mini-CMS estático para GitHub Pages.

## Incluído
- `data/links.json`
- `/admin/` com adicionar, editar, apagar, reordenar, ocultar/publicar e destacar
- drag & drop e setas para ordenação
- preview em tempo real
- importação/exportação JSON
- gravação local no browser via localStorage

## Publicar alterações
Nesta V1.1, o CMS não escreve diretamente no GitHub (para não expor tokens).
1. Edita em `/admin/`.
2. Clica `Exportar JSON`.
3. Substitui `data/links.json` no repositório.
4. Commit/push. O GitHub Pages atualiza a página.

## Teste local
Não abras por `file://`, porque a página usa `fetch()`.
Na pasta do projeto executa:
`python -m http.server 8080`
Depois abre `http://localhost:8080/` e `http://localhost:8080/admin/`.

## GitHub Pages
Settings > Pages > Deploy from a branch > `main` > `/(root)`.
