// V1.0 — altera apenas os URLs abaixo quando tiveres os links definitivos.
const links = [
  { icon:"⚜", title:"Quero ser Escuteiro!", subtitle:"Vem viver esta aventura connosco", url:"#", featured:true },
  { icon:"🌐", title:"Visitar o nosso site", subtitle:"Conhece o Agrupamento 676", url:"#"},
  { icon:"📅", title:"Próximas atividades", subtitle:"Agenda e novidades do Agrupamento", url:"#"},
  { icon:"📸", title:"Instagram", subtitle:"Acompanha as nossas aventuras", url:"#"},
  { icon:"ⓕ", title:"Facebook", subtitle:"Notícias e comunidade", url:"#"},
  { icon:"📍", title:"Onde estamos", subtitle:"Cristo-Rei · Vila Nova de Gaia", url:"#"},
  { icon:"✉", title:"Contactar o Agrupamento", subtitle:"Fala connosco", url:"#"}
];

const box = document.querySelector("#links");
box.innerHTML = links.map(x => `
  <a class="link ${x.featured ? "featured":""}" href="${x.url}" ${x.url !== "#" ? 'target="_blank" rel="noopener"' : 'data-placeholder="true"'}>
    <span class="icon">${x.icon}</span>
    <span class="copy"><b>${x.title}</b><small>${x.subtitle}</small></span>
    <span class="arrow">›</span>
  </a>`).join("");

const toast = document.querySelector("#toast");
document.addEventListener("click", e => {
  const a = e.target.closest('[data-placeholder="true"]');
  if(!a) return;
  e.preventDefault();
  toast.classList.add("show");
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(()=>toast.classList.remove("show"),1600);
});
