# Agrupamento 676 — Links V1.0

Página de links estática, preparada para GitHub Pages.

## Publicar no GitHub Pages
1. Cria um repositório no GitHub (ex.: `agr676-links`).
2. Coloca na raiz do repositório: `index.html`, `style.css`, `links.js` e a pasta `assets`.
3. Faz commit/push para a branch `main`.
4. No GitHub: **Settings → Pages → Build and deployment**.
5. Em **Source**, escolhe **Deploy from a branch**.
6. Seleciona **main** e **/(root)** e guarda.
7. O GitHub apresentará o endereço público da página.

## Alterar links
Edita apenas o array `links` no ficheiro `links.js`.
Troca cada `url:"#"` pelo URL real.

Os links das quatro Secções e das redes sociais no rodapé estão inicialmente como placeholders
e podem ser substituídos diretamente no `index.html`.

## Logótipo
`assets/logo-676.svg` é um emblema provisório criado para esta V1.0.
Substitui-o pelo logótipo oficial mantendo o nome `logo-676.svg` (ou altera a referência no HTML).

## Estrutura
- `index.html`
- `style.css`
- `links.js`
- `assets/logo-676.svg`
- `README.md`

Não usa PHP nem base de dados, portanto funciona diretamente no GitHub Pages.
