# Agrupamento 676 Links — V1.2

CMS estático para GitHub Pages com publicação direta no GitHub.

## V1.2
- botão **🚀 Publicar**
- repositório predefinido: `adrvalente/agr676-links`
- branch: `main`
- ficheiro: `data/links.json`
- lê o SHA atual e atualiza o ficheiro pela GitHub Contents API
- commit automático: `676 CMS: atualização dos links`
- tratamento de erros 401/403/404/409
- Importar/Exportar JSON mantido

## Configurar a publicação
1. Cria/publica o repositório `adrvalente/agr676-links`.
2. No GitHub cria um **fine-grained Personal Access Token** limitado apenas a `agr676-links`.
3. Dá apenas **Repository permissions → Contents: Read and write**.
4. No CMS abre **⚙ GitHub**, cola o token e guarda a sessão.
5. Edita e carrega em **🚀 Publicar**.

O token não está no código, no JSON nem no repositório. É guardado em `sessionStorage` e removido com **Desligar** ou quando a sessão do separador termina.

> Nota de segurança: como esta V1.2 continua a ser 100% GitHub Pages, a credencial é usada pelo browser durante a publicação. Usa um token fine-grained, limitado a este único repositório e só a Contents. Uma futura versão multiutilizador deverá usar GitHub App + backend/serverless para que nenhuma credencial de escrita seja tratada no frontend.
